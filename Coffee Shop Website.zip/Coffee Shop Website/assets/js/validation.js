// MR.COFFEE Form Validation

// Function to validate the entire form
function validateForm() {
    let isValid = true;
    
    // Validate name
    if (!validateName()) {
        isValid = false;
    }
    
    // Validate email
    if (!validateEmail()) {
        isValid = false;
    }
    
    // Validate phone
    if (!validatePhone()) {
        isValid = false;
    }
    
    // Validate product selection
    if (!validateProduct()) {
        isValid = false;
    }
    
    // Validate quantity
    if (!validateQuantity()) {
        isValid = false;
    }
    
    return isValid;
}

// 1. Name Validation
function validateName() {
    const nameInput = document.getElementById('name');
    const nameError = document.getElementById('nameError');
    
    if (!nameInput || !nameError) return true;
    
    // Reset error message
    nameError.textContent = '';
    
    // Check if empty
    if (nameInput.value.trim() === '') {
        nameError.textContent = 'Name is required';
        return false;
    }
    
    // Check minimum length
    if (nameInput.value.trim().length < 3) {
        nameError.textContent = 'Name must be at least 3 characters';
        return false;
    }
    
    // Check for numbers or special characters
    if (/[0-9!@#$%^&*(),.?":{}|<>]/.test(nameInput.value)) {
        nameError.textContent = 'Name should not contain numbers or special characters';
        return false;
    }
    
    return true;
}

// 2. Email Validation
function validateEmail() {
    const emailInput = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    
    if (!emailInput || !emailError) return true;
    
    // Reset error message
    emailError.textContent = '';
    
    // Check if empty
    if (emailInput.value.trim() === '') {
        emailError.textContent = 'Email is required';
        return false;
    }
    
    // Check basic email format without regex
    const email = emailInput.value.trim();
    
    // Check for @ symbol
    if (!email.includes('@')) {
        emailError.textContent = 'Email must contain @ symbol';
        return false;
    }
    
    // Check parts before and after @
    const parts = email.split('@');
    if (parts.length !== 2 || parts[0].length === 0) {
        emailError.textContent = 'Invalid email format';
        return false;
    }
    
    // Check domain part
    const domainParts = parts[1].split('.');
    if (domainParts.length < 2 || domainParts[domainParts.length - 1].length < 2) {
        emailError.textContent = 'Invalid domain in email';
        return false;
    }
    
    return true;
}

// 3. Phone Validation
function validatePhone() {
    const phoneInput = document.getElementById('phone');
    const phoneError = document.getElementById('phoneError');
    
    if (!phoneInput || !phoneError) return true;
    
    // Reset error message
    phoneError.textContent = '';
    
    // Check if empty
    if (phoneInput.value.trim() === '') {
        phoneError.textContent = 'Phone number is required';
        return false;
    }
    
    const phone = phoneInput.value.trim();
    
    // Check if contains only digits, spaces, dashes, parentheses, and plus sign
    for (let i = 0; i < phone.length; i++) {
        const char = phone.charAt(i);
        if (!'0123456789 -+()'.includes(char)) {
            phoneError.textContent = 'Phone number can only contain digits, spaces, dashes, parentheses, and plus sign';
            return false;
        }
    }
    
    // Count digits
    let digitCount = 0;
    for (let i = 0; i < phone.length; i++) {
        if ('0123456789'.includes(phone.charAt(i))) {
            digitCount++;
        }
    }
    
    // Check minimum digits
    if (digitCount < 10) {
        phoneError.textContent = 'Phone number must have at least 10 digits';
        return false;
    }
    
    return true;
}

// 4. Product Validation
function validateProduct() {
    const productSelect = document.getElementById('product');
    const productError = document.getElementById('productError');
    
    if (!productSelect || !productError) return true;
    
    // Reset error message
    productError.textContent = '';
    
    // Check if a product is selected
    if (productSelect.value === '') {
        productError.textContent = 'Please select a product';
        return false;
    }
    
    return true;
}

// 5. Quantity Validation
function validateQuantity() {
    const quantityInput = document.getElementById('quantity');
    const quantityError = document.getElementById('quantityError');
    
    if (!quantityInput || !quantityError) return true;
    
    // Reset error message
    quantityError.textContent = '';
    
    // Check if empty
    if (quantityInput.value.trim() === '') {
        quantityError.textContent = 'Quantity is required';
        return false;
    }
    
    // Check if it's a number
    const quantity = parseInt(quantityInput.value);
    if (isNaN(quantity)) {
        quantityError.textContent = 'Quantity must be a number';
        return false;
    }
    
    // Check if it's positive
    if (quantity <= 0) {
        quantityError.textContent = 'Quantity must be greater than 0';
        return false;
    }
    
    // Check if it's a whole number
    if (quantity !== parseFloat(quantityInput.value)) {
        quantityError.textContent = 'Quantity must be a whole number';
        return false;
    }
    
    return true;
}

// Add event listeners for real-time validation
document.addEventListener('DOMContentLoaded', function() {
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');
    const productSelect = document.getElementById('product');
    const quantityInput = document.getElementById('quantity');
    
    // Add blur event listeners for validation
    if (nameInput) nameInput.addEventListener('blur', validateName);
    if (emailInput) emailInput.addEventListener('blur', validateEmail);
    if (phoneInput) phoneInput.addEventListener('blur', validatePhone);
    if (productSelect) productSelect.addEventListener('change', validateProduct);
    if (quantityInput) quantityInput.addEventListener('blur', validateQuantity);
});