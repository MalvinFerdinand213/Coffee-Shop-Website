// MR.COFFEE Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
    
    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.menu-toggle') && !event.target.closest('.nav-menu')) {
            if (navMenu && navMenu.classList.contains('active')) {
                navMenu.classList.remove('active');
            }
        }
    });
    
    // Menu Filter
    const filterButtons = document.querySelectorAll('.filter-btn');
    const menuItems = document.querySelectorAll('.menu-item');
    
    if (filterButtons.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                
                // Add active class to clicked button
                button.classList.add('active');
                
                // Get filter value
                const filterValue = button.getAttribute('data-filter');
                
                // Filter menu items
                menuItems.forEach(item => {
                    if (filterValue === 'all' || item.getAttribute('data-category') === filterValue) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });
    }
    
    // Rewards Modal
    const rewardButtons = document.querySelectorAll('.reward-btn');
    const downloadModal = document.getElementById('download-modal');
    const closeModal = document.querySelector('.close-modal');
    
    if (rewardButtons.length > 0 && downloadModal) {
        rewardButtons.forEach(button => {
            button.addEventListener('click', () => {
                downloadModal.style.display = 'flex';
            });
        });
        
        closeModal.addEventListener('click', () => {
            downloadModal.style.display = 'none';
        });
        
        window.addEventListener('click', (event) => {
            if (event.target === downloadModal) {
                downloadModal.style.display = 'none';
            }
        });
    }
    
    // Order Form Price Calculation
    const productSelect = document.getElementById('product');
    const quantityInput = document.getElementById('quantity');
    const addons = document.querySelectorAll('input[name="addons"]');
    const totalPriceElement = document.getElementById('totalPrice');
    
    // Function to calculate total price
    function calculateTotalPrice() {
        if (!productSelect || !quantityInput || !totalPriceElement) return;
        
        let basePrice = 0;
        const selectedOption = productSelect.options[productSelect.selectedIndex];
        
        if (selectedOption && selectedOption.value) {
            // Extract price from option text (e.g., "Classic Espresso - $3.99")
            const priceText = selectedOption.text.split('$')[1];
            if (priceText) {
                basePrice = parseFloat(priceText);
            }
        }
        
        // Calculate quantity price
        const quantity = parseInt(quantityInput.value) || 1;
        let totalPrice = basePrice * quantity;
        
        // Add addon prices
        addons.forEach(addon => {
            if (addon.checked) {
                const addonPrice = parseFloat(addon.getAttribute('data-price')) || 0;
                totalPrice += addonPrice * quantity;
            }
        });
        
        // Update total price display
        totalPriceElement.textContent = `$${totalPrice.toFixed(2)}`;
    }
    
    // Add event listeners for price calculation
    if (productSelect && quantityInput && addons.length > 0) {
        productSelect.addEventListener('change', calculateTotalPrice);
        quantityInput.addEventListener('change', calculateTotalPrice);
        quantityInput.addEventListener('input', calculateTotalPrice);
        
        addons.forEach(addon => {
            addon.addEventListener('change', calculateTotalPrice);
        });
    }
    
    // Order Form Submission and Modal
    const orderForm = document.getElementById('orderForm');
    const orderModal = document.getElementById('orderModal');
    const orderSummary = document.getElementById('orderSummary');
    const closeOrderModal = document.getElementById('closeModal');

    // Dummy validateForm function (replace with actual validation logic or import)
    function validateForm() {
        // In a real application, this function would contain actual form validation logic.
        // For this example, we'll just return true to simulate successful validation.
        return true;
    }
    
    if (orderForm && orderModal && orderSummary) {
        orderForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            // Validate form (validation.js handles this)
            if (validateForm()) {
                // Create order summary
                const name = document.getElementById('name').value;
                const email = document.getElementById('email').value;
                const product = productSelect.options[productSelect.selectedIndex].text;
                const quantity = quantityInput.value;
                const totalPrice = totalPriceElement.textContent;
                
                let selectedAddons = [];
                addons.forEach(addon => {
                    if (addon.checked) {
                        selectedAddons.push(addon.nextElementSibling.textContent);
                    }
                });
                
                // Build summary HTML
                let summaryHTML = `
                    <p><strong>Name:</strong> ${name}</p>
                    <p><strong>Email:</strong> ${email}</p>
                    <p><strong>Order:</strong> ${quantity}x ${product}</p>
                `;
                
                if (selectedAddons.length > 0) {
                    summaryHTML += `<p><strong>Add-ons:</strong> ${selectedAddons.join(', ')}</p>`;
                }
                
                summaryHTML += `<p><strong>Total:</strong> ${totalPrice}</p>`;
                
                // Update summary and show modal
                orderSummary.innerHTML = summaryHTML;
                orderModal.style.display = 'flex';
            }
        });
        
        // Close order modal
        if (closeOrderModal) {
            closeOrderModal.addEventListener('click', () => {
                orderModal.style.display = 'none';
                orderForm.reset();
                calculateTotalPrice();
            });
        }
        
        // Close modal when clicking outside
        window.addEventListener('click', (event) => {
            if (event.target === orderModal) {
                orderModal.style.display = 'none';
                orderForm.reset();
                calculateTotalPrice();
            }
        });
    }
    
    // Initialize price calculation on page load
    if (productSelect && quantityInput) {
        calculateTotalPrice();
    }
});